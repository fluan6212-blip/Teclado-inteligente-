SMARTKEY AI — TECLADO ANDROID DE TESTE
======================================

O projeto foi preparado para teste rápido.

O que ele faz:
- É um teclado Android real (InputMethodService).
- A interface do teclado é feita no index.html.
- A chave Gemini NÃO está gravada no código.
- A chave é inserida pelo próprio usuário no aplicativo e fica salva localmente.
- O teclado pode enviar a resposta gerada para o campo de texto que estiver selecionado.
- A mesma interface pode ser aberta pelo ícone normal do aplicativo para configurar a chave.

COMO GERAR O APK
----------------
1. Instale o Android Studio no computador.
2. Abra a pasta SmartKeyAI como projeto.
3. Aguarde o Gradle sincronizar.
4. Vá em Build > Build APK(s).
5. Instale o APK no Android.

COMO ATIVAR O TECLADO
---------------------
Depois de instalar:
1. Abra o aplicativo SmartKey AI.
2. Entre em API.
3. Cole sua chave do Gemini.
4. Salve.
5. Abra as configurações do Android.
6. Procure por "Teclado na tela", "Teclado virtual" ou "Teclados".
7. Ative "SmartKey AI".
8. Abra o WhatsApp.
9. Toque no campo de mensagem.
10. Troque o teclado atual para SmartKey AI.
11. Teste um comando e toque em "Gerar resposta".
12. Toque em "Inserir no campo".

IMPORTANTE
----------
- A chave não está neste projeto.
- Não publique uma chave pessoal dentro do HTML.
- O acesso direto à API pelo cliente é adequado para protótipo/teste, mas não é uma arquitetura segura para um produto público em escala.
- O modelo padrão fica configurado no HTML e pode ser alterado depois.
- O projeto usa o endpoint generateContent da API Gemini.

OBSERVAÇÃO
----------
O projeto foi feito para teste e não para produção. Antes de distribuir para usuários, seria recomendável criar uma arquitetura de backend para proteger credenciais e controlar uso/custos.
