package com.smartkey.ai;

import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class SmartKeyInputMethodService extends InputMethodService implements GeminiBridge.WebViewHost {
    private WebView webView;
    private GeminiBridge bridge;

    @Override
    public View onCreateInputView() {
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setTextZoom(100);

        webView.setWebViewClient(new WebViewClient());

        bridge = new GeminiBridge(this, this);
        webView.addJavascriptInterface(bridge, "Android");

        webView.loadUrl("file:///android_asset/index.html");
        return webView;
    }

    @Override
    public void onStartInput(EditorInfo attribute, boolean restarting) {
        super.onStartInput(attribute, restarting);
    }

    @Override
    public void onFinishInput() {
        super.onFinishInput();
    }

    @Override
    public void insertText(String text) {
        if (text == null) return;
        if (getCurrentInputConnection() != null) {
            getCurrentInputConnection().commitText(text, 1);
        } else {
            showMessage("Não foi possível acessar o campo de texto.");
        }
    }

    @Override
    public void showMessage(String message) {
        if (message != null && !message.isEmpty()) {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void runJavascript(String script) {
        if (webView != null) {
            webView.post(() -> webView.evaluateJavascript(script, null));
        }
    }

    @Override
    public void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
