package com.smartkey.ai;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GeminiBridge {
    public interface Host {
        void insertText(String text);
        void showMessage(String message);
    }

    private static final String PREFS = "smartkey_settings";
    private static final String KEY_API = "gemini_api_key";
    private final Context context;
    private final Host host;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    public GeminiBridge(Context context, Host host) {
        this.context = context.getApplicationContext();
        this.host = host;
    }

    @JavascriptInterface
    public void saveApiKey(String apiKey) {
        SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putString(KEY_API, apiKey == null ? "" : apiKey.trim()).apply();
        host.showMessage("Chave salva neste aparelho.");
    }

    @JavascriptInterface
    public String hasApiKey() {
        SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String key = sp.getString(KEY_API, "");
        return key.isEmpty() ? "false" : "true";
    }

    @JavascriptInterface
    public void clearApiKey() {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().remove(KEY_API).apply();
        host.showMessage("Chave removida.");
    }

    @JavascriptInterface
    public void generateGemini(final String prompt, final String model, final String temperature) {
        final String apiKey = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_API, "");

        if (apiKey == null || apiKey.trim().isEmpty()) {
            sendResult(false, "Nenhuma chave Gemini foi configurada no aplicativo.");
            return;
        }

        final String safeModel = (model == null || model.trim().isEmpty())
                ? "gemini-3.6-flash" : model.trim();

        final double temp;
        try {
            temp = Math.max(0.0, Math.min(2.0, Double.parseDouble(temperature)));
        } catch (Exception e) {
            sendResult(false, "Temperatura inválida.");
            return;
        }

        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                String endpoint = "https://generativelanguage.googleapis.com/v1beta/models/"
                        + java.net.URLEncoder.encode(safeModel, "UTF-8")
                        + ":generateContent";

                URL url = new URL(endpoint);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(45000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("x-goog-api-key", apiKey);

                JSONObject body = new JSONObject();

                JSONObject system = new JSONObject();
                JSONArray systemParts = new JSONArray();
                systemParts.put(new JSONObject().put("text",
                        "Você é o assistente SmartKey AI. Responda em português do Brasil. "
                        + "Ajude o usuário com produtividade, vendas, mensagens, textos e respostas rápidas. "
                        + "Se o usuário pedir uma resposta para um cliente, entregue um texto pronto para copiar, "
                        + "natural, claro e profissional, sem explicar o processo."
                ));
                system.put("parts", systemParts);
                body.put("system_instruction", system);

                JSONArray contents = new JSONArray();
                JSONObject userContent = new JSONObject();
                userContent.put("role", "user");
                JSONArray userParts = new JSONArray();
                userParts.put(new JSONObject().put("text", prompt == null ? "" : prompt));
                userContent.put("parts", userParts);
                contents.put(userContent);
                body.put("contents", contents);

                JSONObject generation = new JSONObject();
                generation.put("temperature", temp);
                generation.put("maxOutputTokens", 1200);
                body.put("generationConfig", generation);

                byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = connection.getOutputStream()) {
                    os.write(payload);
                }

                int code = connection.getResponseCode();
                InputStream stream = (code >= 200 && code < 300)
                        ? connection.getInputStream()
                        : connection.getErrorStream();

                String responseBody = readAll(stream);

                if (code < 200 || code >= 300) {
                    String message = extractApiError(responseBody);
                    sendResult(false, "Gemini retornou HTTP " + code + ": " + message);
                    return;
                }

                String answer = extractText(responseBody);
                if (answer.isEmpty()) {
                    sendResult(false, "A API respondeu, mas não foi encontrada uma resposta de texto.");
                } else {
                    sendResult(true, answer);
                }

            } catch (Exception e) {
                sendResult(false, "Erro ao conectar ao Gemini: " + e.getMessage());
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private void sendResult(final boolean ok, final String text) {
        main.post(() -> {
            String js = "window.onNativeGeminiResult("
                    + (ok ? "true" : "false") + ","
                    + JSONObject.quote(text == null ? "" : text)
                    + ")";
            host.showMessage("");
            if (host instanceof WebViewHost) {
                ((WebViewHost) host).runJavascript(js);
            }
        });
    }

    private String readAll(InputStream input) throws Exception {
        if (input == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private String extractText(String json) throws Exception {
        JSONObject root = new JSONObject(json);
        JSONArray candidates = root.optJSONArray("candidates");
        if (candidates == null || candidates.length() == 0) return "";

        JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
        if (content == null) return "";

        JSONArray parts = content.optJSONArray("parts");
        if (parts == null) return "";

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < parts.length(); i++) {
            JSONObject part = parts.optJSONObject(i);
            if (part != null && part.has("text")) {
                if (result.length() > 0) result.append("\n");
                result.append(part.optString("text", ""));
            }
        }
        return result.toString().trim();
    }

    private String extractApiError(String json) {
        try {
            JSONObject root = new JSONObject(json);
            JSONObject error = root.optJSONObject("error");
            if (error != null) {
                String msg = error.optString("message", "");
                if (!msg.isEmpty()) return msg;
            }
        } catch (Exception ignored) {}
        return json == null || json.isEmpty() ? "Erro desconhecido." : json;
    }

    public interface WebViewHost extends Host {
        void runJavascript(String script);
    }
}
